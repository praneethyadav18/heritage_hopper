
// HERITAGEHOPPER JAVASCRIPT

// 1. MONUMENT DATA

const monuments = {
    golconda: {
        name: "Golconda Fort",
        stops: {
            1: {
                title: "Fateh Darwaza",
                en: "Welcome to Golconda Fort. Fateh Darwaza is an important entrance to the fort. Its architecture reflects the defensive engineering of the historic Golconda kingdom.",
                te: "గోల్కొండ కోటకు స్వాగతం. ఫతే దర్వాజా ఈ కోటలోని ముఖ్యమైన ప్రవేశ ద్వారం. దీని నిర్మాణం చారిత్రక గోల్కొండ రాజ్య రక్షణ వ్యవస్థను తెలియజేస్తుంది.",
                hi: "गोलकोंडा किले में आपका स्वागत है। फतेह दरवाजा किले का एक महत्वपूर्ण प्रवेश द्वार है। इसकी वास्तुकला गोलकोंडा साम्राज्य की रक्षा व्यवस्था को दर्शाती है।"
            },
            2: {
                title: "Clapping Portico",
                en: "Discover the fascinating acoustic design of Golconda Fort. A clap near the entrance can be heard at a designated point high above the fort, demonstrating its historic communication system.",
                te: "గోల్కొండ కోటలోని అద్భుతమైన శబ్ద వ్యవస్థను తెలుసుకోండి. ప్రవేశ ద్వారం దగ్గర చప్పట్లు కొడితే, కోటలోని పైభాగంలో ఉన్న నిర్దిష్ట ప్రదేశంలో ఆ శబ్దం వినిపిస్తుంది.",
                hi: "गोलकोंडा किले की अद्भुत ध्वनि प्रणाली को जानिए। प्रवेश द्वार के पास ताली बजाने पर किले के ऊपरी हिस्से में एक निर्धारित स्थान पर इसकी आवाज सुनाई देती है।"
            },
            3: {
                title: "Rani Mahal",
                en: "Rani Mahal is associated with the royal residential spaces of Golconda. Explore the stories of royal life and the architectural heritage of this historic fort.",
                te: "రాణి మహల్ గోల్కొండ రాజ కుటుంబ నివాస ప్రాంతాలతో సంబంధం కలిగి ఉంది. రాజ కుటుంబ జీవితం మరియు కోట నిర్మాణ వారసత్వాన్ని తెలుసుకోండి.",
                hi: "रानी महल गोलकोंडा के शाही आवासीय क्षेत्रों से जुड़ा हुआ है। यहां के शाही जीवन और ऐतिहासिक वास्तुकला की कहानियों को जानिए।"
            },
            4: {
                title: "Baradari",
                en: "Baradari is a historic pavilion within Golconda Fort. Explore its architecture and imagine the royal activities that once took place here.",
                te: "బారాదరి గోల్కొండ కోటలోని ఒక చారిత్రక మండపం. దీని నిర్మాణాన్ని పరిశీలించి, గతంలో ఇక్కడ జరిగిన రాజకుటుంబ కార్యక్రమాలను ఊహించుకోండి.",
                hi: "बारादरी गोलकोंडा किले का एक ऐतिहासिक मंडप है। इसकी वास्तुकला को देखें और यहां होने वाली शाही गतिविधियों की कल्पना करें।"
            }
        }
    },

    charminar: {
        name: "Charminar",
        stops: {
            1: {
                title: "Charminar Entrance",
                en: "Welcome to Charminar, one of Hyderabad's most recognizable monuments. It was built in 1591 by Muhammad Quli Qutb Shah.",
                te: "చార్మినార్‌కు స్వాగతం. ఇది హైదరాబాద్‌లోని ప్రసిద్ధ చారిత్రక కట్టడాలలో ఒకటి. దీనిని 1591లో మహమ్మద్ కులీ కుతుబ్ షా నిర్మించారు.",
                hi: "चारमीनार में आपका स्वागत है। यह हैदराबाद के प्रसिद्ध ऐतिहासिक स्मारकों में से एक है। इसका निर्माण 1591 में मुहम्मद कुली कुतुब शाह ने करवाया था।"
            }
        }
    },

    hampi: {
        name: "Hampi",
        stops: {
            1: {
                title: "Hampi Heritage",
                en: "Welcome to Hampi, the historic capital of the Vijayanagara Empire. Discover its temples, stone structures and architectural heritage.",
                te: "హంపికి స్వాగతం. ఇది విజయనగర సామ్రాజ్యపు చారిత్రక రాజధాని. ఇక్కడి దేవాలయాలు మరియు రాతి నిర్మాణాల వారసత్వాన్ని తెలుసుకోండి.",
                hi: "हम्पी में आपका स्वागत है। यह विजयनगर साम्राज्य की ऐतिहासिक राजधानी थी। यहां के मंदिरों और पत्थर की संरचनाओं की विरासत को जानिए।"
            }
        }
    }
};

let selectedMonument = "golconda";
let currentStop = 1;
let currentStory = null;
let currentSpeed = 1;
let scanner = null;


// 2. SELECT MONUMENT

function selectMonument(name) {
    selectedMonument = name;
    currentStop = 1;
    loadStop(1);

    document.getElementById("audio").scrollIntoView({
        behavior: "smooth"
    });
}


// 3. LOAD CHECKPOINT

function loadStop(number) {
    const stop = monuments[selectedMonument].stops[number];

    if (!stop) {
        document.getElementById("scanMessage").textContent =
            "This checkpoint is not available for this monument yet.";
        return;
    }

    currentStop = number;
    currentStory = stop;

    document.getElementById("audioTitle").textContent =
        stop.title;

    document.getElementById("audioDescription").textContent =
        stop.en;

    document.getElementById("scanMessage").textContent =
        "Checkpoint " + String(number).padStart(2, "0") +
        " loaded successfully!";

    document.getElementById("stopNumber").value =
        String(number).padStart(2, "0");

    document.getElementById("audio").scrollIntoView({
        behavior: "smooth"
    });
}


// 4. MULTILINGUAL AUDIO

function playAudio() {
    if (!currentStory) {
        document.getElementById("audioStatus").textContent =
            "Please select a checkpoint first.";
        return;
    }

    if (!("speechSynthesis" in window)) {
        document.getElementById("audioStatus").textContent =
            "Speech narration is not supported in this browser.";
        return;
    }

    speechSynthesis.cancel();

    const language =
        document.getElementById("language").value;

    let story = currentStory.en;

    if (language === "te-IN") {
        story = currentStory.te;
    }

    if (language === "hi-IN") {
        story = currentStory.hi;
    }

    const speech = new SpeechSynthesisUtterance(story);

    speech.lang = language;
    speech.rate = currentSpeed;

    speech.onstart = function() {
        document.getElementById("audioStatus").textContent =
            "Playing historical narration...";
    };

    speech.onend = function() {
        document.getElementById("audioStatus").textContent =
            "Narration completed.";
    };

    speech.onerror = function() {
        document.getElementById("audioStatus").textContent =
            "Audio error. Try another language.";
    };

    speechSynthesis.speak(speech);
}


// 5. PAUSE AUDIO

function pauseAudio() {
    speechSynthesis.pause();

    document.getElementById("audioStatus").textContent =
        "Audio paused.";
}


// 6. STOP AUDIO

function stopAudio() {
    speechSynthesis.cancel();

    document.getElementById("audioStatus").textContent =
        "Audio stopped.";
}


// 7. CHANGE AUDIO SPEED

function changeSpeed() {
    currentSpeed = Number(
        document.getElementById("speed").value
    );

    if (speechSynthesis.speaking) {
        playAudio();
    }
}


// 8. CHECKPOINT NUMBER ENTRY

function openCheckpoint() {
    const value = document.getElementById("stopNumber")
        .value.trim();

    const number = Number(value);

    if (!Number.isInteger(number) || number < 1 || number > 4) {
        document.getElementById("scanMessage").textContent =
            "Please enter a valid checkpoint number (01-04).";
        return;
    }

    loadStop(number);
}


// 9. QR SCANNER

function startScanner() {
    if (!window.isSecureContext) {
        document.getElementById("scanMessage").textContent =
            "Camera access requires HTTPS or localhost.";
        return;
    }

    if (typeof Html5Qrcode === "undefined") {
        document.getElementById("scanMessage").textContent =
            "QR scanner library could not load. Check your internet.";
        return;
    }

    if (scanner) {
        return;
    }

    scanner = new Html5Qrcode("reader");

    scanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: 220 },

        function(decodedText) {
            // QR codes should contain a number like 01 or 02.
            const match = decodedText.match(/(?:STOP[-_ ]?)?0?([1-4])$/i);

            if (match) {
                scanner.stop().then(() => {
                    scanner = null;
                    document.getElementById("stopNumber").value =
                        match[1];
                    openCheckpoint();
                });
            } else {
                document.getElementById("scanMessage").textContent =
                    "QR code must contain a checkpoint number (01-04).";
            }
        },

        function() {
            // Ignore unsuccessful camera frame scans.
        }

    ).catch(function(error) {
        scanner = null;

        document.getElementById("scanMessage").textContent =
            "Camera could not start. Check camera permission.";
    });
}


// 10. HISTORICAL TIMELINE

function updateTimeline() {
    const year = Number(
        document.getElementById("yearSlider").value
    );

    document.getElementById("year").textContent = year;

    let message;

    if (year < 1600) {
        message =
            "Golconda developed as an important fortified settlement during the early Qutb Shahi period.";
    }
    else if (year < 1700) {
        message =
            "Golconda became a significant centre of power, trade and architecture under the Qutb Shahi dynasty.";
    }
    else if (year < 1900) {
        message =
            "The fort experienced changes following the Mughal conquest in 1687 and later historical periods.";
    }
    else if (year < 2026) {
        message =
            "Golconda Fort became an important historical heritage attraction and preservation site.";
    }
    else {
        message =
            "2026: Explore and preserve Golconda's architectural heritage for future generations.";
    }

    document.getElementById("timelineText").textContent =
        message;
}


// 11. SAVE VISITOR NOTES AND PHOTOS

function saveNote() {
    const name = document.getElementById("visitorName")
        .value.trim();

    const note = document.getElementById("visitorNote")
        .value.trim();

    const photoFile = document.getElementById("visitorPhoto")
        .files[0];

    if (!name || !note) {
        alert("Please enter your name and memory.");
        return;
    }

    if (photoFile && photoFile.size > 1024 * 1024) {
        alert("Please select a photo smaller than 1 MB.");
        return;
    }

    const saveMemory = function(photoData) {
        const memories = JSON.parse(
            localStorage.getItem("heritageMemories") || "[]"
        );

        memories.push({
            name: name,
            note: note,
            photo: photoData,
            date: new Date().toLocaleDateString()
        });

        try {
            localStorage.setItem(
                "heritageMemories",
                JSON.stringify(memories)
            );

            displayNotes();

            document.getElementById("visitorNote").value = "";
            document.getElementById("visitorPhoto").value = "";

            alert("Your memory has been saved!");
        } catch (error) {
            alert("Storage is full. Try a smaller photo.");
        }
    };

    if (photoFile) {
        const reader = new FileReader();

        reader.onload = function(event) {
            saveMemory(event.target.result);
        };

        reader.onerror = function() {
            alert("Unable to read the selected photo.");
        };

        reader.readAsDataURL(photoFile);
    } else {
        saveMemory(null);
    }
}


// 12. DISPLAY SAVED MEMORIES

function displayNotes() {
    const memories = JSON.parse(
        localStorage.getItem("heritageMemories") || "[]"
    );

    const container =
        document.getElementById("savedNotes");

    container.innerHTML = "";

    memories.slice().reverse().forEach(function(memory) {
        const card = document.createElement("div");
        card.className = "saved-note";

        const heading = document.createElement("h3");
        heading.textContent = memory.name;

        const paragraph = document.createElement("p");
        paragraph.textContent = memory.note;

        const date = document.createElement("small");
        date.textContent = memory.date;

        card.append(heading, paragraph, date);

        if (memory.photo) {
            const img = document.createElement("img");
            img.src = memory.photo;
            img.alt = "Saved visitor memory";
            card.appendChild(img);
        }

        container.appendChild(card);
    });
}


// 13. LOAD SAVED MEMORIES WHEN PAGE OPENS

window.addEventListener("DOMContentLoaded", function() {
    displayNotes();
    updateTimeline();
});


// 14. REGISTER SERVICE WORKER FOR OFFLINE SUPPORT

if ("serviceWorker" in navigator) {
    window.addEventListener("load", function() {
        navigator.serviceWorker.register("./sw.js")
            .then(function() {
                console.log("Offline support enabled.");
            })
            .catch(function(error) {
                console.log("Service worker error:", error);
            });
    });
}
